using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using StudentDept.Models;
using SAL;
using BOL;
namespace StudentDept.Controllers;

public class StudentController : Controller
{
    private readonly ILogger<StudentController> _logger;

    public StudentController(ILogger<StudentController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        StudentService ss=new StudentService();  
        List<Student> slist=ss.GetAll();
        ViewData["students"]=slist;

        return View();
    }

   

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
