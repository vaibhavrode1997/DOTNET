﻿namespace BLL;
using BOL;
using DAL;
public class StudentManager
{
    public List<Student> GetAll(){
        CollectionContext ctx=new CollectionContext();
        //var student=from stud in ctx.stud2 select stud;
        var q=from stud in ctx.stud2
               join dept in ctx.dept2 on stud.DeptId equals dept.DeptId
               select new { StudId=stud.StudId,StudName=stud.StudName,DeptName=dept.DeptName 
               };
          return q;     


    }
}
