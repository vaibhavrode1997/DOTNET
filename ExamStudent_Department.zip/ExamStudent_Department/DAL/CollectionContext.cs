﻿using Microsoft.EntityFrameworkCore;
using BOL;
namespace DAL;
public class CollectionContext : DbContext
{
    public DbSet<Student> stud2{get;set;}
    public DbSet<Department> dept2{get;set;}
     protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder){
        string url = @"server=localhost ;user=root;password=Vaibhav@1812;database=vaibhavdb";
        optionBuilder.UseMySQL(url);
        
     }    

}
