﻿namespace SAL;
using BOL;
using BLL;

public class StudentService
{
    public List<Student> GetAll(){
        StudentManager mgr=new StudentManager();
        return mgr.GetAll(); 
    }
}
