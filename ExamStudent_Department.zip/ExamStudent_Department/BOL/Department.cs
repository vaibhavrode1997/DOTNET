namespace BOL;
public class Department
{
    
    public int DeptId{get;set;}
    public string DeptName{get;set;}

}