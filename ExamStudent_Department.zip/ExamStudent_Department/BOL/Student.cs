﻿namespace BOL;
using System.ComponentModel.DataAnnotations;
public class Student
{
    [Key]
    public int StudId{get;set;}
    public string StudName{get;set;}
    public string DeptId{get;set;}

}
